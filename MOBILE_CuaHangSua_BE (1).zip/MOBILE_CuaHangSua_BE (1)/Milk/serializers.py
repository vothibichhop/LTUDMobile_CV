from django.conf import settings
from rest_framework import serializers

from .models import (
    BannerQuangCao,
    ChiTietDonHang,
    ChiTietGioHang,
    DanhMucSanPham,
    DonHang,
    GioHang,
    LuaChonMuaSua,
    NguoiDung,
    Sua,
)


def dinh_dang_tien(value):
    return f"{int(value):,}".replace(",", ".") + "\u0111"


ANDROID_MEDIA_BASE_URL = getattr(settings, "ANDROID_MEDIA_BASE_URL", "").rstrip("/")


def build_android_media_url(request, image_field):
    if not image_field:
        return ""

    relative_url = image_field.url
    if request is not None:
        return request.build_absolute_uri(relative_url)
    if ANDROID_MEDIA_BASE_URL:
        return f"{ANDROID_MEDIA_BASE_URL}{relative_url}"
    return relative_url


class SuaListQuerySerializer(serializers.Serializer):
    q = serializers.CharField(required=False, allow_blank=True, default="")
    hang_sua = serializers.CharField(required=False, allow_blank=True)
    loai_sua = serializers.CharField(required=False, allow_blank=True)
    danh_muc = serializers.CharField(required=False, allow_blank=True)


class SuaListSerializer(serializers.ModelSerializer):
    ma_hang_sua = serializers.CharField(source="hang_sua_id", read_only=True)
    ten_hang_sua = serializers.CharField(source="hang_sua.ten_hang_sua", read_only=True)
    ma_loai_sua = serializers.CharField(source="loai_sua_id", read_only=True)
    ten_loai_sua = serializers.CharField(source="loai_sua.ten_loai_sua", read_only=True)
    ma_danh_muc = serializers.CharField(source="danh_muc_id", read_only=True)
    ten_danh_muc = serializers.CharField(source="danh_muc.ten_danh_muc", read_only=True)
    thong_tin_hien_thi = serializers.SerializerMethodField()
    gia_hien_thi = serializers.SerializerMethodField()
    nhan_giam_gia = serializers.SerializerMethodField()
    hinh = serializers.SerializerMethodField()

    class Meta:
        model = Sua
        fields = [
            "ma_sua",
            "ten_sua",
            "ma_hang_sua",
            "ten_hang_sua",
            "ma_loai_sua",
            "ten_loai_sua",
            "ma_danh_muc",
            "ten_danh_muc",
            "quy_cach",
            "trong_luong",
            "don_vi",
            "thong_tin_hien_thi",
            "don_gia",
            "gia_hien_thi",
            "giam_gia",
            "nhan_giam_gia",
            "thanh_phan",
            "loi_ich",
            "hinh",
        ]

    def get_thong_tin_hien_thi(self, obj):
        if obj.quy_cach:
            return obj.quy_cach
        if obj.trong_luong and obj.don_vi:
            return f"{obj.trong_luong} {obj.don_vi}"
        return ""

    def get_gia_hien_thi(self, obj):
        return dinh_dang_tien(obj.don_gia)

    def get_nhan_giam_gia(self, obj):
        if not obj.giam_gia:
            return ""
        return f"-{obj.giam_gia}%"

    def get_hinh(self, obj):
        return build_android_media_url(self.context.get("request"), obj.hinh)


class DanhMucSanPhamSerializer(serializers.ModelSerializer):
    ma_loai_sua = serializers.CharField(source="loai_sua_id", read_only=True)
    tong_san_pham = serializers.IntegerField(source="san_pham.count", read_only=True)

    class Meta:
        model = DanhMucSanPham
        fields = [
            "ma_danh_muc",
            "ten_danh_muc",
            "noi_bat",
            "so_luong_hien_thi",
            "tong_san_pham",
            "thu_tu",
            "hien_thi",
            "ma_loai_sua",
        ]


class ChiTietDanhMucSanPhamSerializer(serializers.ModelSerializer):
    ma_loai_sua = serializers.CharField(source="loai_sua_id", read_only=True)
    tong_san_pham = serializers.IntegerField(source="san_pham.count", read_only=True)
    san_pham = SuaListSerializer(many=True, read_only=True)

    class Meta:
        model = DanhMucSanPham
        fields = [
            "ma_danh_muc",
            "ten_danh_muc",
            "mo_ta",
            "noi_bat",
            "so_luong_hien_thi",
            "tong_san_pham",
            "thu_tu",
            "hien_thi",
            "ma_loai_sua",
            "san_pham",
        ]


class BannerQuangCaoSerializer(serializers.ModelSerializer):
    ma_sua = serializers.CharField(source="sua_id", read_only=True)
    ten_sua = serializers.CharField(source="sua.ten_sua", read_only=True)
    ma_danh_muc = serializers.CharField(source="sua.danh_muc_id", read_only=True)
    ten_danh_muc = serializers.CharField(source="sua.danh_muc.ten_danh_muc", read_only=True)
    hinh = serializers.SerializerMethodField()
    thong_tin_hien_thi = serializers.SerializerMethodField()
    gia_hien_thi = serializers.SerializerMethodField()

    class Meta:
        model = BannerQuangCao
        fields = [
            "ma_banner",
            "tieu_de",
            "mo_ta",
            "nhan",
            "mau_nen",
            "mau_chu",
            "thu_tu",
            "hien_thi",
            "ma_sua",
            "ten_sua",
            "ma_danh_muc",
            "ten_danh_muc",
            "thong_tin_hien_thi",
            "gia_hien_thi",
            "hinh",
        ]

    def get_thong_tin_hien_thi(self, obj):
        if obj.sua is None:
            return ""
        if obj.sua.quy_cach:
            return obj.sua.quy_cach
        if obj.sua.trong_luong and obj.sua.don_vi:
            return f"{obj.sua.trong_luong} {obj.sua.don_vi}"
        return ""

    def get_gia_hien_thi(self, obj):
        if obj.sua is None:
            return ""
        return dinh_dang_tien(obj.sua.don_gia)

    def get_hinh(self, obj):
        if obj.sua is None:
            return ""
        return build_android_media_url(self.context.get("request"), obj.sua.hinh)


class LuaChonMuaSuaSerializer(serializers.ModelSerializer):
    gia_hien_thi = serializers.SerializerMethodField()
    nhan_giam_gia = serializers.SerializerMethodField()

    class Meta:
        model = LuaChonMuaSua
        fields = [
            "id",
            "ten_lua_chon",
            "don_gia",
            "gia_hien_thi",
            "giam_gia",
            "nhan_giam_gia",
            "mac_dinh",
            "thu_tu",
            "hien_thi",
        ]

    def get_gia_hien_thi(self, obj):
        return dinh_dang_tien(obj.don_gia)

    def get_nhan_giam_gia(self, obj):
        if not obj.giam_gia:
            return ""
        return f"-{obj.giam_gia}%"


class ChiTietSuaSerializer(serializers.ModelSerializer):
    ma_hang_sua = serializers.CharField(source="hang_sua_id", read_only=True)
    ten_hang_sua = serializers.CharField(source="hang_sua.ten_hang_sua", read_only=True)
    ma_loai_sua = serializers.CharField(source="loai_sua_id", read_only=True)
    ten_loai_sua = serializers.CharField(source="loai_sua.ten_loai_sua", read_only=True)
    ma_danh_muc = serializers.CharField(source="danh_muc_id", read_only=True)
    ten_danh_muc = serializers.CharField(source="danh_muc.ten_danh_muc", read_only=True)
    mo_ta_chi_tiet = serializers.SerializerMethodField()
    thong_tin_hien_thi = serializers.SerializerMethodField()
    gia_hien_thi = serializers.SerializerMethodField()
    nhan_giam_gia = serializers.SerializerMethodField()
    lua_chon_mua = serializers.SerializerMethodField()
    hinh = serializers.SerializerMethodField()

    class Meta:
        model = Sua
        fields = [
            "ma_sua",
            "ten_sua",
            "ma_hang_sua",
            "ten_hang_sua",
            "ma_loai_sua",
            "ten_loai_sua",
            "ma_danh_muc",
            "ten_danh_muc",
            "mo_ta_chi_tiet",
            "quy_cach",
            "trong_luong",
            "don_vi",
            "thong_tin_hien_thi",
            "don_gia",
            "gia_hien_thi",
            "giam_gia",
            "nhan_giam_gia",
            "thanh_phan",
            "loi_ich",
            "hinh",
            "lua_chon_mua",
        ]

    def get_thong_tin_hien_thi(self, obj):
        if obj.quy_cach:
            return obj.quy_cach
        if obj.trong_luong and obj.don_vi:
            return f"{obj.trong_luong} {obj.don_vi}"
        return ""

    def get_mo_ta_chi_tiet(self, obj):
        if obj.mo_ta_chi_tiet:
            return obj.mo_ta_chi_tiet

        detail_parts = []
        if obj.thanh_phan:
            detail_parts.append(f"Th\u00e0nh ph\u1ea7n n\u1ed5i b\u1eadt: {obj.thanh_phan}.")
        if obj.loi_ich:
            detail_parts.append(f"L\u1ee3i \u00edch ch\u00ednh: {obj.loi_ich}.")
        if obj.quy_cach:
            detail_parts.append(f"Quy c\u00e1ch \u0111\u00f3ng g\u00f3i: {obj.quy_cach}.")

        return " ".join(detail_parts)

    def get_gia_hien_thi(self, obj):
        return dinh_dang_tien(obj.don_gia)

    def get_nhan_giam_gia(self, obj):
        if not obj.giam_gia:
            return ""
        return f"-{obj.giam_gia}%"

    def get_hinh(self, obj):
        return build_android_media_url(self.context.get("request"), obj.hinh)

    def get_lua_chon_mua(self, obj):
        lua_chon_hien_thi = obj.lua_chon_mua.filter(hien_thi=True)
        if lua_chon_hien_thi.exists():
            return LuaChonMuaSuaSerializer(lua_chon_hien_thi, many=True, context=self.context).data

        ten_lua_chon = self.get_thong_tin_hien_thi(obj) or "Quy c\u00e1ch chu\u1ea9n"
        return [
            {
                "id": None,
                "ten_lua_chon": ten_lua_chon,
                "don_gia": int(obj.don_gia),
                "gia_hien_thi": self.get_gia_hien_thi(obj),
                "giam_gia": obj.giam_gia,
                "nhan_giam_gia": self.get_nhan_giam_gia(obj),
                "mac_dinh": True,
                "thu_tu": 1,
                "hien_thi": True,
            }
        ]


class ThemSanPhamVaoGioHangSerializer(serializers.Serializer):
    ma_sua = serializers.CharField(required=False)
    ma_sp = serializers.CharField(required=False)
    ten_sp = serializers.CharField(required=False, allow_blank=True)
    gia = serializers.IntegerField(required=False, min_value=0)
    lua_chon_mua_id = serializers.IntegerField(required=False, allow_null=True)
    so_luong = serializers.IntegerField(min_value=1, default=1)
    quy_cach = serializers.CharField(required=False, allow_blank=True)
    hinh_anh = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        ma_sua = attrs.get("ma_sua") or attrs.get("ma_sp")
        if not ma_sua:
            raise serializers.ValidationError({"ma_sp": "Truong nay la bat buoc."})

        try:
            sua = Sua.objects.prefetch_related("lua_chon_mua").get(ma_sua=ma_sua)
        except Sua.DoesNotExist as exc:
            raise serializers.ValidationError({"ma_sp": "San pham khong ton tai."}) from exc

        lua_chon_mua_id = attrs.get("lua_chon_mua_id")
        if lua_chon_mua_id is not None:
            try:
                lua_chon_mua = sua.lua_chon_mua.get(id=lua_chon_mua_id, hien_thi=True)
            except LuaChonMuaSua.DoesNotExist as exc:
                raise serializers.ValidationError(
                    {"lua_chon_mua_id": "Lua chon mua khong hop le cho san pham nay."}
                ) from exc
        else:
            lua_chon_mua = (
                sua.lua_chon_mua.filter(hien_thi=True, mac_dinh=True).order_by("thu_tu", "id").first()
                or sua.lua_chon_mua.filter(hien_thi=True).order_by("thu_tu", "id").first()
            )

        attrs["sua"] = sua
        attrs["ma_sua"] = ma_sua
        attrs["lua_chon_mua"] = lua_chon_mua
        return attrs


class CapNhatChiTietGioHangSerializer(serializers.Serializer):
    so_luong = serializers.IntegerField(min_value=1, required=False)
    lua_chon_mua_id = serializers.IntegerField(required=False, allow_null=True)

    def validate(self, attrs):
        if not attrs:
            raise serializers.ValidationError("Can gui it nhat mot truong de cap nhat.")

        chi_tiet = self.context["chi_tiet"]
        if "lua_chon_mua_id" in attrs:
            lua_chon_mua_id = attrs["lua_chon_mua_id"]
            if lua_chon_mua_id is None:
                lua_chon_mua = (
                    chi_tiet.sua.lua_chon_mua.filter(hien_thi=True, mac_dinh=True)
                    .order_by("thu_tu", "id")
                    .first()
                )
            else:
                try:
                    lua_chon_mua = chi_tiet.sua.lua_chon_mua.get(
                        id=lua_chon_mua_id,
                        hien_thi=True,
                    )
                except LuaChonMuaSua.DoesNotExist as exc:
                    raise serializers.ValidationError(
                        {"lua_chon_mua_id": "Lua chon mua khong hop le cho san pham nay."}
                    ) from exc
            attrs["lua_chon_mua"] = lua_chon_mua
        return attrs


class ChiTietGioHangSerializer(serializers.ModelSerializer):
    ma_sua = serializers.CharField(source="sua_id", read_only=True)
    ma_sp = serializers.CharField(source="sua_id", read_only=True)
    ten_sua = serializers.CharField(source="sua.ten_sua", read_only=True)
    ten_sp = serializers.CharField(source="sua.ten_sua", read_only=True)
    hinh = serializers.SerializerMethodField()
    hinh_anh = serializers.SerializerMethodField()
    ma_danh_muc = serializers.CharField(source="sua.danh_muc_id", read_only=True)
    ten_danh_muc = serializers.CharField(source="sua.danh_muc.ten_danh_muc", read_only=True)
    lua_chon_mua_id = serializers.SerializerMethodField()
    ten_lua_chon = serializers.SerializerMethodField()
    thong_tin_hien_thi = serializers.SerializerMethodField()
    don_gia = serializers.SerializerMethodField()
    gia_hien_thi = serializers.SerializerMethodField()
    giam_gia = serializers.SerializerMethodField()
    nhan_giam_gia = serializers.SerializerMethodField()
    thanh_tien = serializers.SerializerMethodField()
    thanh_tien_hien_thi = serializers.SerializerMethodField()
    product_id = serializers.IntegerField(source="id", read_only=True)
    gia = serializers.SerializerMethodField()
    quy_cach = serializers.SerializerMethodField()

    class Meta:
        model = ChiTietGioHang
        fields = [
            "id",
            "product_id",
            "ma_sua",
            "ma_sp",
            "ten_sua",
            "ten_sp",
            "hinh",
            "hinh_anh",
            "ma_danh_muc",
            "ten_danh_muc",
            "lua_chon_mua_id",
            "ten_lua_chon",
            "thong_tin_hien_thi",
            "don_gia",
            "gia",
            "gia_hien_thi",
            "giam_gia",
            "nhan_giam_gia",
            "quy_cach",
            "so_luong",
            "thanh_tien",
            "thanh_tien_hien_thi",
        ]

    def _don_gia(self, obj):
        if obj.lua_chon_mua is not None:
            return obj.lua_chon_mua.don_gia
        return obj.sua.don_gia

    def _giam_gia(self, obj):
        if obj.lua_chon_mua is not None:
            return obj.lua_chon_mua.giam_gia
        return obj.sua.giam_gia

    def get_lua_chon_mua_id(self, obj):
        if obj.lua_chon_mua is None:
            return None
        return obj.lua_chon_mua.id

    def get_ten_lua_chon(self, obj):
        if obj.lua_chon_mua is not None:
            return obj.lua_chon_mua.ten_lua_chon
        if obj.sua.quy_cach:
            return obj.sua.quy_cach
        if obj.sua.trong_luong and obj.sua.don_vi:
            return f"{obj.sua.trong_luong} {obj.sua.don_vi}"
        return "Quy c\u00e1ch chu\u1ea9n"

    def get_thong_tin_hien_thi(self, obj):
        return self.get_ten_lua_chon(obj)

    def get_don_gia(self, obj):
        return int(self._don_gia(obj))

    def get_gia(self, obj):
        return self.get_don_gia(obj)

    def get_gia_hien_thi(self, obj):
        return dinh_dang_tien(self._don_gia(obj))

    def get_giam_gia(self, obj):
        return self._giam_gia(obj)

    def get_nhan_giam_gia(self, obj):
        giam_gia = self._giam_gia(obj)
        if not giam_gia:
            return ""
        return f"-{giam_gia}%"

    def get_thanh_tien(self, obj):
        return int(self._don_gia(obj) * obj.so_luong)

    def get_thanh_tien_hien_thi(self, obj):
        return dinh_dang_tien(self._don_gia(obj) * obj.so_luong)

    def get_hinh(self, obj):
        return build_android_media_url(self.context.get("request"), obj.sua.hinh)

    def get_hinh_anh(self, obj):
        return self.get_hinh(obj)

    def get_quy_cach(self, obj):
        return self.get_ten_lua_chon(obj)


class GioHangSerializer(serializers.ModelSerializer):
    items = ChiTietGioHangSerializer(source="chi_tiet", many=True, read_only=True)
    san_pham = ChiTietGioHangSerializer(source="chi_tiet", many=True, read_only=True)
    tong_mat_hang = serializers.SerializerMethodField()
    tong_so_luong = serializers.SerializerMethodField()
    tong_tien = serializers.SerializerMethodField()
    tong_tien_hien_thi = serializers.SerializerMethodField()
    cart_id = serializers.UUIDField(source="ma_gio_hang", read_only=True)

    class Meta:
        model = GioHang
        fields = [
            "cart_id",
            "ma_gio_hang",
            "tao_luc",
            "cap_nhat_luc",
            "tong_mat_hang",
            "tong_so_luong",
            "tong_tien",
            "tong_tien_hien_thi",
            "items",
            "san_pham",
        ]

    def get_tong_mat_hang(self, obj):
        return obj.chi_tiet.count()

    def get_tong_so_luong(self, obj):
        return sum(item.so_luong for item in obj.chi_tiet.all())

    def get_tong_tien(self, obj):
        tong = 0
        for item in obj.chi_tiet.all():
            if item.lua_chon_mua is not None:
                tong += int(item.lua_chon_mua.don_gia) * item.so_luong
            else:
                tong += int(item.sua.don_gia) * item.so_luong
        return tong

    def get_tong_tien_hien_thi(self, obj):
        return dinh_dang_tien(self.get_tong_tien(obj))


class ChiTietDonHangSerializer(serializers.ModelSerializer):
    ten_sp = serializers.CharField(source="san_pham.ten_sua", read_only=True)
    hinh_anh = serializers.SerializerMethodField()
    gia_ban = serializers.SerializerMethodField()

    class Meta:
        model = ChiTietDonHang
        fields = ["ten_sp", "so_luong", "gia_ban", "hinh_anh"]

    def get_hinh_anh(self, obj):
        return build_android_media_url(self.context.get("request"), obj.san_pham.hinh)

    def get_gia_ban(self, obj):
        return float(obj.gia_ban)


class DonHangSerializer(serializers.ModelSerializer):
    san_pham = ChiTietDonHangSerializer(many=True, read_only=True)
    tong_tien = serializers.SerializerMethodField()
    ngay_dat = serializers.SerializerMethodField()
    trang_thai = serializers.SerializerMethodField()

    class Meta:
        model = DonHang
        fields = ["id", "ngay_dat", "trang_thai", "tong_tien", "san_pham"]

    def get_tong_tien(self, obj):
        return float(obj.tong_tien)

    def get_ngay_dat(self, obj):
        return obj.ngay_dat.strftime("%d/%m/%Y %H:%M")

    def get_trang_thai(self, obj):
        trang_thai_map = {
            "Dang giao": "\u0110ang giao",
            "Da giao": "Ho\u00e0n th\u00e0nh",
            "Da huy": "\u0110\u00e3 h\u1ee7y",
            "Cho xac nhan": "Ch\u1edd x\u00e1c nh\u1eadn",
        }
        return trang_thai_map.get(obj.trang_thai, obj.trang_thai)


class DangNhapSerializer(serializers.Serializer):
    so_dien_thoai = serializers.CharField(allow_blank=False)
    mat_khau = serializers.CharField(allow_blank=False, trim_whitespace=False)


class NguoiDungSerializer(serializers.ModelSerializer):
    ho_ten = serializers.SerializerMethodField()

    class Meta:
        model = NguoiDung
        fields = ["id", "ho_ten", "ho_ten_dem", "ten", "so_dien_thoai", "dia_chi"]

    def get_ho_ten(self, obj):
        return " ".join(part for part in [obj.ho_ten_dem, obj.ten] if part).strip()


class DangKySerializer(serializers.ModelSerializer):
    class Meta:
        model = NguoiDung
        fields = ["ho_ten_dem", "ten", "so_dien_thoai", "mat_khau"]
        extra_kwargs = {"mat_khau": {"write_only": True}}


class CartItemSimpleSerializer(serializers.Serializer):
    """Serializer đơn giản cho danh sách sản phẩm trong giỏ hàng - dành cho Android app"""
    ma_sua = serializers.SerializerMethodField()
    ten_sp = serializers.SerializerMethodField()
    hinh_anh = serializers.SerializerMethodField()
    quy_cach = serializers.SerializerMethodField()
    gia = serializers.SerializerMethodField()
    so_luong = serializers.IntegerField()

    def get_ma_sua(self, obj):
        return obj.sua_id

    def get_ten_sp(self, obj):
        return obj.sua.ten_sua

    def get_hinh_anh(self, obj):
        return build_android_media_url(self.context.get("request"), obj.sua.hinh)

    def get_quy_cach(self, obj):
        if obj.lua_chon_mua:
            return obj.lua_chon_mua.ten_lua_chon
        if obj.sua.quy_cach:
            return obj.sua.quy_cach
        if obj.sua.trong_luong and obj.sua.don_vi:
            return f"{obj.sua.trong_luong} {obj.sua.don_vi}"
        return "Quy cách chuẩn"

    def get_gia(self, obj):
        if obj.lua_chon_mua:
            return int(obj.lua_chon_mua.don_gia)
        return int(obj.sua.don_gia)


class ThanhToanSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()
    cart_id = serializers.UUIDField()
    full_name = serializers.CharField(max_length=100)
    phone = serializers.CharField(max_length=20)
    address = serializers.CharField()
    payment_method = serializers.CharField(max_length=50, default="COD")
    total_amount = serializers.DecimalField(max_digits=12, decimal_places=1)

