from django.contrib import admin

from .models import ChiTietDonHang, DonHang, NguoiDung


class ChiTietDonHangInline(admin.TabularInline):
    model = ChiTietDonHang
    extra = 1


@admin.register(DonHang)
class DonHangAdmin(admin.ModelAdmin):
    list_display = ("id", "ngay_dat", "trang_thai", "tong_tien")
    search_fields = ("id", "trang_thai")
    list_filter = ("trang_thai", "ngay_dat")
    inlines = [ChiTietDonHangInline]


@admin.register(NguoiDung)
class NguoiDungAdmin(admin.ModelAdmin):
    list_display = ('so_dien_thoai', 'ho_ten_dem', 'ten', 'dang_hoat_dong')
    search_fields = ('so_dien_thoai', 'ho_ten_dem', 'ten')
    list_filter = ('dang_hoat_dong', 'tao_luc')
