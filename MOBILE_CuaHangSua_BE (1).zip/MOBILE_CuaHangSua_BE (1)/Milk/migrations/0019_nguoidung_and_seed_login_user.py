from django.contrib.auth.hashers import make_password
from django.db import migrations, models


def seed_sample_user(apps, schema_editor):
    NguoiDung = apps.get_model("Milk", "NguoiDung")
    NguoiDung.objects.update_or_create(
        so_dien_thoai="0333733121",
        defaults={
            "ho_ten": "Phạm Hoài",
            "mat_khau": make_password("123123"),
            "dang_hoat_dong": True,
        },
    )


def rollback_sample_user(apps, schema_editor):
    NguoiDung = apps.get_model("Milk", "NguoiDung")
    NguoiDung.objects.filter(so_dien_thoai="0333733121").delete()


class Migration(migrations.Migration):

    dependencies = [
        ("Milk", "0018_expand_order_history_seed_data"),
    ]

    operations = [
        migrations.CreateModel(
            name="NguoiDung",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("ho_ten", models.CharField(max_length=100)),
                ("so_dien_thoai", models.CharField(max_length=20, unique=True)),
                ("mat_khau", models.CharField(max_length=128)),
                ("dang_hoat_dong", models.BooleanField(default=True)),
                ("tao_luc", models.DateTimeField(auto_now_add=True)),
                ("cap_nhat_luc", models.DateTimeField(auto_now=True)),
            ],
            options={
                "verbose_name": "Nguoi dung",
                "verbose_name_plural": "Nguoi dung",
                "ordering": ["id"],
            },
        ),
        migrations.RunPython(seed_sample_user, rollback_sample_user),
    ]
