import datetime

from django.db import migrations


ORDER_SEED_DATA = [
    {
        "id": "DH001",
        "ngay_dat": datetime.datetime(2026, 2, 4, 14, 30, tzinfo=datetime.timezone.utc),
        "trang_thai": "Dang giao",
        "tong_tien": 199000.0,
        "san_pham": [
            {"san_pham_id": "S10", "so_luong": 1, "gia_ban": 45000.0},
            {"san_pham_id": "S01", "so_luong": 1, "gia_ban": 154000.0},
        ],
    },
    {
        "id": "DH002",
        "ngay_dat": datetime.datetime(2026, 2, 1, 8, 0, tzinfo=datetime.timezone.utc),
        "trang_thai": "Da giao",
        "tong_tien": 356000.0,
        "san_pham": [
            {"san_pham_id": "S11", "so_luong": 2, "gia_ban": 178000.0},
        ],
    },
    {
        "id": "DH003",
        "ngay_dat": datetime.datetime(2026, 1, 28, 15, 45, tzinfo=datetime.timezone.utc),
        "trang_thai": "Da huy",
        "tong_tien": 490000.0,
        "san_pham": [
            {"san_pham_id": "S02", "so_luong": 1, "gia_ban": 490000.0},
        ],
    },
]


def seed_expanded_order_history(apps, schema_editor):
    DonHang = apps.get_model("Milk", "DonHang")
    ChiTietDonHang = apps.get_model("Milk", "ChiTietDonHang")
    Sua = apps.get_model("Milk", "Sua")

    DonHang.objects.filter(id="DH123").delete()

    for order in ORDER_SEED_DATA:
        don_hang, _ = DonHang.objects.update_or_create(
            id=order["id"],
            defaults={
                "ngay_dat": order["ngay_dat"],
                "trang_thai": order["trang_thai"],
                "tong_tien": order["tong_tien"],
            },
        )

        ChiTietDonHang.objects.filter(don_hang=don_hang).delete()
        for item in order["san_pham"]:
            if Sua.objects.filter(ma_sua=item["san_pham_id"]).exists():
                ChiTietDonHang.objects.create(
                    don_hang=don_hang,
                    san_pham_id=item["san_pham_id"],
                    so_luong=item["so_luong"],
                    gia_ban=item["gia_ban"],
                )


def rollback_expanded_order_history(apps, schema_editor):
    DonHang = apps.get_model("Milk", "DonHang")
    DonHang.objects.filter(id__in=["DH001", "DH002", "DH003"]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("Milk", "0017_donhang_chitietdonhang_and_seed_data"),
    ]

    operations = [
        migrations.RunPython(seed_expanded_order_history, rollback_expanded_order_history),
    ]
