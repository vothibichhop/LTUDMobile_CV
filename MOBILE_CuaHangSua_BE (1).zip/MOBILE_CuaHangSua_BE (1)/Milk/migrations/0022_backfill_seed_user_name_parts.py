from django.db import migrations


def backfill_seed_user_name_parts(apps, schema_editor):
    NguoiDung = apps.get_model("Milk", "NguoiDung")
    NguoiDung.objects.filter(
        so_dien_thoai="0333733121",
        ho_ten_dem="",
        ten="",
    ).update(
        ho_ten_dem="Ph\u1ea1m",
        ten="Ho\u00e0i",
    )


def rollback_seed_user_name_parts(apps, schema_editor):
    NguoiDung = apps.get_model("Milk", "NguoiDung")
    NguoiDung.objects.filter(
        so_dien_thoai="0333733121",
        ho_ten_dem="Ph\u1ea1m",
        ten="Ho\u00e0i",
    ).update(
        ho_ten_dem="",
        ten="",
    )


class Migration(migrations.Migration):

    dependencies = [
        ("Milk", "0021_donhang_dia_chi_donhang_ho_ten_donhang_nguoi_dung_and_more"),
    ]

    operations = [
        migrations.RunPython(
            backfill_seed_user_name_parts,
            rollback_seed_user_name_parts,
        ),
    ]
