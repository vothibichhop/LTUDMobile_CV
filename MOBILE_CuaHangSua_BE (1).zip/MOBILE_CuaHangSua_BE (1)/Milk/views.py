from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import BannerQuangCao, ChiTietDonHang, ChiTietGioHang, DanhMucSanPham, DonHang, GioHang, NguoiDung, Sua
from .serializers import (
    BannerQuangCaoSerializer,
    CapNhatChiTietGioHangSerializer,
    CartItemSimpleSerializer,
    ChiTietDanhMucSanPhamSerializer,
    ChiTietSuaSerializer,
    DanhMucSanPhamSerializer,
    DangKySerializer,
    DangNhapSerializer,
    DonHangSerializer,
    GioHangSerializer,
    NguoiDungSerializer,
    SuaListQuerySerializer,
    SuaListSerializer,
    ThemSanPhamVaoGioHangSerializer,
    ThanhToanSerializer,
)


class SuaViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    lookup_field = "ma_sua"

    def get_queryset(self):
        queryset = (
            Sua.objects.select_related("hang_sua", "loai_sua", "danh_muc")
            .prefetch_related("lua_chon_mua")
            .order_by("ma_sua")
        )

        query_serializer = SuaListQuerySerializer(data=self.request.query_params)
        query_serializer.is_valid(raise_exception=True)
        params = query_serializer.validated_data

        if params.get("q"):
            queryset = queryset.filter(
                Q(ten_sua__icontains=params["q"])
                | Q(quy_cach__icontains=params["q"])
                | Q(thanh_phan__icontains=params["q"])
                | Q(loi_ich__icontains=params["q"])
            )
        if params.get("hang_sua"):
            queryset = queryset.filter(hang_sua_id=params["hang_sua"])
        if params.get("loai_sua"):
            queryset = queryset.filter(loai_sua_id=params["loai_sua"])
        if params.get("danh_muc"):
            queryset = queryset.filter(danh_muc_id=params["danh_muc"])

        return queryset

    def get_serializer_class(self):
        if self.action == "retrieve":
            return ChiTietSuaSerializer
        return SuaListSerializer

    @action(detail=False, methods=["get"], url_path="danh-sach-san-pham")
    def danh_sach_san_pham(self, request):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        return Response(serializer.data)


class DanhMucSanPhamViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    lookup_field = "ma_danh_muc"

    def get_queryset(self):
        return (
            DanhMucSanPham.objects.filter(hien_thi=True)
            .select_related("loai_sua")
            .prefetch_related("san_pham__hang_sua", "san_pham__loai_sua", "san_pham__danh_muc")
            .order_by("thu_tu", "ma_danh_muc")
        )

    def get_serializer_class(self):
        if self.action == "retrieve":
            return ChiTietDanhMucSanPhamSerializer
        return DanhMucSanPhamSerializer

    @action(detail=False, methods=["get"], url_path="danh-muc")
    def danh_muc(self, request):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        return Response(serializer.data)

    @action(detail=False, methods=["get"], url_path="chi-tiet-danh-muc")
    def chi_tiet_danh_muc(self, request):
        serializer = ChiTietDanhMucSanPhamSerializer(
            self.get_queryset(),
            many=True,
            context={"request": request},
        )
        return Response(serializer.data)


class BannerQuangCaoViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    serializer_class = BannerQuangCaoSerializer
    lookup_field = "ma_banner"

    def get_queryset(self):
        return (
            BannerQuangCao.objects.filter(hien_thi=True)
            .select_related("sua", "sua__danh_muc")
            .order_by("thu_tu", "ma_banner")
        )

    @action(detail=False, methods=["get"], url_path="banner")
    def banner(self, request):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        return Response(serializer.data)


class GioHangViewSet(viewsets.ViewSet):
    def _get_queryset(self):
        return GioHang.objects.prefetch_related(
            "chi_tiet__sua__danh_muc",
            "chi_tiet__lua_chon_mua",
        )

    def _get_gio_hang(self, ma_gio_hang):
        return get_object_or_404(self._get_queryset(), ma_gio_hang=ma_gio_hang)

    def _touch_gio_hang(self, gio_hang):
        GioHang.objects.filter(ma_gio_hang=gio_hang.ma_gio_hang).update(cap_nhat_luc=timezone.now())

    def _serialize_gio_hang(self, gio_hang, request, status_code=status.HTTP_200_OK):
        gio_hang = self._get_gio_hang(gio_hang.ma_gio_hang)
        serializer = GioHangSerializer(gio_hang, context={"request": request})
        return Response(serializer.data, status=status_code)

    def _serialize_danh_sach_san_pham(self, gio_hang, request, status_code=status.HTTP_200_OK):
        gio_hang = self._get_gio_hang(gio_hang.ma_gio_hang)
        serializer = GioHangSerializer(gio_hang, context={"request": request})
        return Response(serializer.data["san_pham"], status=status_code)

    def _them_hoac_cong_don(self, gio_hang, validated_data):
        chi_tiet, created = ChiTietGioHang.objects.get_or_create(
            gio_hang=gio_hang,
            sua=validated_data["sua"],
            lua_chon_mua=validated_data["lua_chon_mua"],
            defaults={"so_luong": validated_data["so_luong"]},
        )
        if not created:
            chi_tiet.so_luong += validated_data["so_luong"]
            chi_tiet.save(update_fields=["so_luong", "cap_nhat_luc"])
        self._touch_gio_hang(gio_hang)
        return chi_tiet

    def create(self, request):
        with transaction.atomic():
            gio_hang = GioHang.objects.create()
            if request.data:
                serializer = ThemSanPhamVaoGioHangSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                self._them_hoac_cong_don(gio_hang, serializer.validated_data)
        return self._serialize_gio_hang(gio_hang, request, status.HTTP_201_CREATED)

    def retrieve(self, request, ma_gio_hang=None):
        gio_hang = self._get_gio_hang(ma_gio_hang)
        return self._serialize_danh_sach_san_pham(gio_hang, request)

    def them_san_pham(self, request, ma_gio_hang=None):
        gio_hang = self._get_gio_hang(ma_gio_hang)
        serializer = ThemSanPhamVaoGioHangSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        with transaction.atomic():
            self._them_hoac_cong_don(gio_hang, serializer.validated_data)
        return self._serialize_gio_hang(gio_hang, request)

    def cap_nhat_chi_tiet(self, request, ma_gio_hang=None, chi_tiet_id=None):
        gio_hang = self._get_gio_hang(ma_gio_hang)
        chi_tiet = get_object_or_404(
            ChiTietGioHang.objects.select_related("sua", "lua_chon_mua").prefetch_related(
                "sua__lua_chon_mua"
            ),
            gio_hang=gio_hang,
            id=chi_tiet_id,
        )
        serializer = CapNhatChiTietGioHangSerializer(
            data=request.data,
            partial=True,
            context={"chi_tiet": chi_tiet},
        )
        serializer.is_valid(raise_exception=True)

        with transaction.atomic():
            so_luong_moi = serializer.validated_data.get("so_luong", chi_tiet.so_luong)
            lua_chon_mua_moi = serializer.validated_data.get("lua_chon_mua", chi_tiet.lua_chon_mua)

            trung_item = (
                ChiTietGioHang.objects.filter(
                    gio_hang=gio_hang,
                    sua=chi_tiet.sua,
                    lua_chon_mua=lua_chon_mua_moi,
                )
                .exclude(id=chi_tiet.id)
                .first()
            )
            if trung_item is not None:
                trung_item.so_luong += so_luong_moi
                trung_item.save(update_fields=["so_luong", "cap_nhat_luc"])
                chi_tiet.delete()
            else:
                chi_tiet.so_luong = so_luong_moi
                chi_tiet.lua_chon_mua = lua_chon_mua_moi
                chi_tiet.save(update_fields=["so_luong", "lua_chon_mua", "cap_nhat_luc"])
            self._touch_gio_hang(gio_hang)

        return self._serialize_gio_hang(gio_hang, request)

    def xoa_chi_tiet(self, request, ma_gio_hang=None, chi_tiet_id=None):
        gio_hang = self._get_gio_hang(ma_gio_hang)
        chi_tiet = get_object_or_404(ChiTietGioHang, gio_hang=gio_hang, id=chi_tiet_id)
        chi_tiet.delete()
        self._touch_gio_hang(gio_hang)
        return self._serialize_gio_hang(gio_hang, request)

    def xoa_tat_ca(self, request, ma_gio_hang=None):
        gio_hang = self._get_gio_hang(ma_gio_hang)
        gio_hang.chi_tiet.all().delete()
        self._touch_gio_hang(gio_hang)
        return self._serialize_gio_hang(gio_hang, request)

    def update_by_product_code(self, request, ma_gio_hang=None, ma_sua=None):
        """Cập nhật số lượng theo mã sản phẩm (dành cho Android app)"""
        gio_hang = self._get_gio_hang(ma_gio_hang)
        chi_tiet = get_object_or_404(
            ChiTietGioHang.objects.select_related("sua", "lua_chon_mua").prefetch_related(
                "sua__lua_chon_mua"
            ),
            gio_hang=gio_hang,
            sua_id=ma_sua,
        )
        so_luong = request.data.get("so_luong")
        if so_luong is None or so_luong < 1:
            return Response({"error": "so_luong must be >= 1"}, status=status.HTTP_400_BAD_REQUEST)

        chi_tiet.so_luong = so_luong
        chi_tiet.save(update_fields=["so_luong", "cap_nhat_luc"])
        self._touch_gio_hang(gio_hang)
        return self._serialize_gio_hang(gio_hang, request)

    def delete_by_product_code(self, request, ma_gio_hang=None, ma_sua=None):
        """Xóa sản phẩm theo mã sản phẩm (dành cho Android app)"""
        gio_hang = self._get_gio_hang(ma_gio_hang)
        chi_tiet = get_object_or_404(ChiTietGioHang, gio_hang=gio_hang, sua_id=ma_sua)
        chi_tiet.delete()
        self._touch_gio_hang(gio_hang)
        return self._serialize_gio_hang(gio_hang, request)

    def get_simple_cart_items(self, request, ma_gio_hang=None):
        """Endpoint dành cho Android app - trả về định dạng đơn giản"""
        gio_hang = self._get_gio_hang(ma_gio_hang)
        chi_tiet_list = gio_hang.chi_tiet.select_related("sua", "lua_chon_mua").all()
        serializer = CartItemSimpleSerializer(
            chi_tiet_list,
            many=True,
            context={"request": request}
        )
        return Response(serializer.data)


class DonHangViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    serializer_class = DonHangSerializer

    def get_queryset(self):
        return DonHang.objects.prefetch_related("san_pham__san_pham").order_by("-ngay_dat", "id")

    @action(detail=False, methods=["get"], url_path="lich-su-don-hang")
    def lich_su_don_hang(self, request):
        serializer = self.get_serializer(
            self.get_queryset(),
            many=True,
            context={"request": request},
        )
        return Response(serializer.data)


class DangKyAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        serializer = DangKySerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.set_password(request.data['mat_khau'])
            user.save()
            return Response({"message": "Thành công"}, status=201)
        return Response(serializer.errors, status=400)


class DangNhapAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        serializer = DangNhapSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {
                    "status": "error",
                    "message": "Vui lòng nhập số điện thoại và mật khẩu",
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        so_dien_thoai = serializer.validated_data["so_dien_thoai"].strip()
        mat_khau = serializer.validated_data["mat_khau"]

        nguoi_dung = (
            NguoiDung.objects.filter(so_dien_thoai=so_dien_thoai, dang_hoat_dong=True).first()
        )
        if nguoi_dung is None or not nguoi_dung.check_password(mat_khau):
            return Response(
                {
                    "status": "error",
                    "message": "Số điện thoại hoặc mật khẩu không chính xác",
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )

        return Response(
            {
                "status": "success",
                "message": "Đăng nhập thành công",
                "user": NguoiDungSerializer(nguoi_dung).data,
            },
            status=status.HTTP_200_OK,
        )


class NguoiDungProfileAPIView(APIView):
    def get(self, request, pk):
        user = get_object_or_404(NguoiDung, pk=pk)
        return Response(NguoiDungSerializer(user).data)

    def put(self, request, pk):
        user = get_object_or_404(NguoiDung, pk=pk)
        user.ho_ten_dem = request.data.get('ho_ten_dem', user.ho_ten_dem)
        user.ten = request.data.get('ten', user.ten)
        user.dia_chi = request.data.get('dia_chi', user.dia_chi)
        user.save()
        return Response(NguoiDungSerializer(user).data)


class ThanhToanAPIView(APIView):
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        serializer = ThanhToanSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        user_id = data['user_id']
        cart_id = data['cart_id']
        full_name = data['full_name']
        phone = data['phone']
        address = data['address']
        payment_method = data['payment_method']
        total_amount = data['total_amount']

        try:
            # Lấy người dùng
            user = NguoiDung.objects.get(id=user_id)

            # Lấy giỏ hàng
            cart = GioHang.objects.prefetch_related('chi_tiet__sua', 'chi_tiet__lua_chon_mua').get(ma_gio_hang=cart_id)

            # Tính lại tổng tiền từ DB để đảm bảo chính xác
            calculated_total = 0
            for item in cart.chi_tiet.all():
                if item.lua_chon_mua:
                    calculated_total += float(item.lua_chon_mua.don_gia) * item.so_luong
                else:
                    calculated_total += float(item.sua.don_gia) * item.so_luong

            # Tạo ID đơn hàng (có thể dùng UUID hoặc timestamp)
            import uuid
            order_id = str(uuid.uuid4())[:20]  # Lấy 20 ký tự đầu

            # Tạo đơn hàng
            order = DonHang.objects.create(
                id=order_id,
                nguoi_dung=user,
                ho_ten=full_name,
                sdt=phone,
                dia_chi=address,
                phuong_thuc_tt=payment_method,
                tong_tien=calculated_total,
                trang_thai="Cho xac nhan"
            )

            # Chuyển chi tiết giỏ hàng sang chi tiết đơn hàng
            for item in cart.chi_tiet.all():
                gia_ban = item.lua_chon_mua.don_gia if item.lua_chon_mua else item.sua.don_gia
                ChiTietDonHang.objects.create(
                    don_hang=order,
                    san_pham=item.sua,
                    so_luong=item.so_luong,
                    gia_ban=gia_ban
                )

            # Xóa giỏ hàng sau khi thanh toán thành công
            cart.chi_tiet.all().delete()

            return Response({
                "status": "success",
                "message": "Đặt hàng thành công",
                "order_id": order_id,
                "total_amount": calculated_total
            }, status=status.HTTP_201_CREATED)

        except NguoiDung.DoesNotExist:
            return Response({"status": "error", "message": "Người dùng không tồn tại"}, status=status.HTTP_404_NOT_FOUND)
        except GioHang.DoesNotExist:
            return Response({"status": "error", "message": "Giỏ hàng không tồn tại"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"status": "error", "message": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
