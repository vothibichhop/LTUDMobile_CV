package com.example.duannhom;

public final class ImageUrlHelper {
    private ImageUrlHelper() {
    }

    public static String resolve(String imageUrl) {
        if (imageUrl == null || imageUrl.trim().isEmpty()) {
            return imageUrl;
        }

        if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
            return imageUrl;
        }

        String normalizedPath = imageUrl.startsWith("/") ? imageUrl.substring(1) : imageUrl;
        return RetrofitClient.getBaseUrl() + normalizedPath;
    }
}
