from django.conf import settings


class SimpleCorsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == "OPTIONS":
            response = self._build_preflight_response()
        else:
            response = self.get_response(request)
        return self._add_cors_headers(response)

    def _build_preflight_response(self):
        from django.http import HttpResponse

        return HttpResponse(status=200)

    def _add_cors_headers(self, response):
        allow_origin = "*" if getattr(settings, "CORS_ALLOW_ALL_ORIGINS", False) else ""
        response["Access-Control-Allow-Origin"] = allow_origin
        response["Access-Control-Allow-Methods"] = ", ".join(
            getattr(settings, "CORS_ALLOW_METHODS", ["GET", "POST", "OPTIONS"])
        )
        response["Access-Control-Allow-Headers"] = ", ".join(
            getattr(settings, "CORS_ALLOW_HEADERS", ["Content-Type", "Authorization"])
        )
        response["Access-Control-Max-Age"] = "86400"
        return response
