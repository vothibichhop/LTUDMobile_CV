package com.example.duannhom;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.text.DecimalFormat;

public class CheckoutSuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_success);

        TextView tvName = findViewById(R.id.tvSuccessName);
        TextView tvPhone = findViewById(R.id.tvSuccessPhone);
        TextView tvAddress = findViewById(R.id.tvSuccessAddress);
        TextView tvSubtotal = findViewById(R.id.tvSuccessSubtotal);
        TextView tvTotal = findViewById(R.id.tvSuccessTotal);
        MaterialButton btnContinue = findViewById(R.id.btnContinueShopping);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String phone = intent.getStringExtra("phone");
        String address = intent.getStringExtra("address");
        long total = intent.getLongExtra("total", 0);

        tvName.setText(name);
        tvPhone.setText(phone);
        tvAddress.setText(address);

        DecimalFormat formatter = new DecimalFormat("#,###");
        String formattedTotal = formatter.format(total).replace(",", ".") + "đ";
        tvSubtotal.setText(formattedTotal);
        tvTotal.setText(formattedTotal);

        btnContinue.setOnClickListener(v -> {
            Intent mainIntent = new Intent(CheckoutSuccessActivity.this, MainActivity.class);
            mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(mainIntent);
            finish();
        });
    }
}