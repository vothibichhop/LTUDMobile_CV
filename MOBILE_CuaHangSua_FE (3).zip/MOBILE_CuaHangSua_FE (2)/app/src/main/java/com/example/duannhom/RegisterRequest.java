package com.example.duannhom;

import com.google.gson.annotations.SerializedName;

public class RegisterRequest {
    @SerializedName("so_dien_thoai")
    private final String phone;
    
    @SerializedName("ho_ten_dem")
    private final String lastName; // Họ và tên đệm

    @SerializedName("ten")
    private final String firstName; // Tên
    
    @SerializedName("mat_khau")
    private final String password;

    public RegisterRequest(String phone, String lastName, String firstName, String password) {
        this.phone = phone;
        this.lastName = lastName;
        this.firstName = firstName;
        this.password = password;
    }
}
