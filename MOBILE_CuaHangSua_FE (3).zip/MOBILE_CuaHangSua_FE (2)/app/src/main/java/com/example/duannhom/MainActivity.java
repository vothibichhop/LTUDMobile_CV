package com.example.duannhom;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvProduct;
    private ProductAdapter productAdapter;
    private List<Product> productList;
    private TextView tvSuccessMessage, tvCartBadge;

    private final CartManager.OnCartChangeListener cartListener = newCount -> {
        if (tvCartBadge != null) {
            if (newCount > 0) {
                tvCartBadge.setVisibility(View.VISIBLE);
                tvCartBadge.setText(String.valueOf(newCount));
            } else {
                tvCartBadge.setVisibility(View.GONE);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSuccessMessage = findViewById(R.id.tvSuccessMessage);
        tvCartBadge = findViewById(R.id.tvCartBadge); 
        rvProduct = findViewById(R.id.rvProduct);
        EditText etSearchMain = findViewById(R.id.etSearchMain);
        ImageView imgCartMain = findViewById(R.id.imgCartMain);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);

        bottomNav.setItemIconTintList(null);

        productList = new ArrayList<>();
        productAdapter = new ProductAdapter(productList);
        rvProduct.setLayoutManager(new GridLayoutManager(this, 3));
        rvProduct.setAdapter(productAdapter);

        fetchProducts();

        etSearchMain.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SearchActivity.class)));
        imgCartMain.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, CartActivity.class)));

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                fetchProducts();
                return true;
            } else if (id == R.id.menu_category) {
                startActivity(new Intent(MainActivity.this, CategoryActivity.class));
                return true;
            } else if (id == R.id.menu_orders) {
                startActivity(new Intent(MainActivity.this, OrderHistoryActivity.class));
                return true;
            } else if (id == R.id.menu_account) {
                startActivity(new Intent(MainActivity.this, AccountActivity.class));
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        CartManager.getInstance().addListener(cartListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        CartManager.getInstance().removeListener(cartListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handleIntent(getIntent());
    }

    private void fetchProducts() {
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        apiService.getMilkProducts().enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("API_SUCCESS", "Products loaded: " + response.body().size());
                    productList.clear();
                    productList.addAll(response.body());
                    productAdapter.notifyDataSetChanged();
                } else {
                    Log.e("API_ERROR", "Response error code: " + response.code());
                }
            }
            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                Log.e("API_ERROR", "Connection failed: " + t.getMessage());
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("show_success", false)) {
            if (tvSuccessMessage != null) {
                tvSuccessMessage.setVisibility(View.VISIBLE);
                intent.putExtra("show_success", false);
                tvSuccessMessage.postDelayed(() -> tvSuccessMessage.setVisibility(View.GONE), 3000);
            }
        }
    }
}