package com.example.duannhom;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class OtpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        EditText etOtp = findViewById(R.id.etOtp);
        findViewById(R.id.btnBackOtp).setOnClickListener(v -> finish());

        // Nhận mã OTP mong đợi từ màn hình trước
        String expectedOtp = getIntent().getStringExtra("EXPECTED_OTP");

        MaterialButton btnVerifyOtp = findViewById(R.id.btnVerifyOtp);
        btnVerifyOtp.setOnClickListener(v -> {
            String enteredOtp = etOtp.getText().toString();

            if (enteredOtp.equals(expectedOtp)) {
                Toast.makeText(this, "Xác thực thành công!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, ResetPasswordActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Mã OTP không chính xác, vui lòng thử lại!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}