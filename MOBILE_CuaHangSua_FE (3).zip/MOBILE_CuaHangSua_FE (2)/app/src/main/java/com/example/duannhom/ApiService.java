package com.example.duannhom;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    @POST("api/dang-ky")
    Call<Void> register(@Body RegisterRequest request);

    @POST("api/dang-nhap")
    Call<LoginResponse> login(@Body LoginRequest request);

    @GET("api/nguoi-dung/{id}")
    Call<User> getUserProfile(@Path("id") int userId);

    @PUT("api/nguoi-dung/{id}/cap-nhat")
    Call<Void> updateUserProfile(@Path("id") int userId, @Body User user);

    @GET("api/danh-sach-san-pham")
    Call<List<Product>> getMilkProducts();

    @GET("api/san-pham-sua/{ma_sua}")
    Call<Product> getProductDetail(@Path("ma_sua") String ma_sua);

    @POST("api/gio-hang")
    Call<CartResponse> createCart();

    @GET("api/gio-hang/{ma_gio_hang}/chi-tiet")
    Call<List<CartItem>> getCartDetails(@Path("ma_gio_hang") String maGioHang);

    @POST("api/gio-hang/{ma_gio_hang}/them-san-pham")
    Call<Void> addProductToCart(@Path("ma_gio_hang") String maGioHang, @Body AddToCartRequest request);

    @PUT("api/gio-hang/{ma_gio_hang}/chi-tiet/{chi_tiet_id}")
    Call<Void> updateCartItemQuantity(@Path("ma_gio_hang") String maGioHang, @Path("chi_tiet_id") String chiTietId, @Body AddToCartRequest request);

    @DELETE("api/gio-hang/{ma_gio_hang}/chi-tiet/{chi_tiet_id}")
    Call<Void> deleteCartItem(@Path("ma_gio_hang") String maGioHang, @Path("chi_tiet_id") String chiTietId);

    @DELETE("api/gio-hang/{ma_gio_hang}/xoa-tat-ca")
    Call<Void> clearCart(@Path("ma_gio_hang") String maGioHang);

    @POST("api/thanh-toan")
    Call<OrderResponse> checkout(@Body CheckoutRequest request);

    @GET("api/danh-muc")
    Call<List<Category>> getCategories();

    @GET("api/chi-tiet-danh-muc/{ma_loai}")
    Call<Category> getCategoryDetail(@Path("ma_loai") String ma_loai);

    @GET("api/banner")
    Call<List<Banner>> getBanners();

    @GET("api/banner-quang-cao")
    Call<List<Banner>> getPromoBanners();

    @GET("api/lich-su-don-hang")
    Call<List<OrderResponse>> getOrderHistory(@Query("user_id") int userId);

    @POST("api/don-hang/{id}/huy")
    Call<Void> cancelOrder(@Path("id") String orderId);
}
