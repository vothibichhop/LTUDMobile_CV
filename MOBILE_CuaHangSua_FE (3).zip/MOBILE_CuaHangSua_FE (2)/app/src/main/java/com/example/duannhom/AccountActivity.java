package com.example.duannhom;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AccountActivity extends AppCompatActivity {

    private EditText etPhone, etLastName, etFirstName, etAddress;
    private MaterialButton btnSaveChanges;
    private ImageView btnBack;
    private TextView tvLogout;
    private int userId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        userId = prefs.getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "Vui lòng đăng nhập lại", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        initViews();
        setupBottomNav();
        fetchUserProfile();

        btnBack.setOnClickListener(v -> finish());
        btnSaveChanges.setOnClickListener(v -> updateUserProfile());

        tvLogout.setOnClickListener(v -> {
            // Xóa thông tin đăng nhập
            SharedPreferences.Editor editor = prefs.edit();
            editor.remove("user_id");
            editor.apply();

            // Chuyển về màn hình đăng nhập
            Intent intent = new Intent(AccountActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void initViews() {
        etPhone = findViewById(R.id.etPhone);
        etLastName = findViewById(R.id.etLastName);
        etFirstName = findViewById(R.id.etFirstName);
        etAddress = findViewById(R.id.etAddress);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnBack = findViewById(R.id.btnBack);
        tvLogout = findViewById(R.id.tvLogout);
    }

    private void fetchUserProfile() {
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        apiService.getUserProfile(userId).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful() && response.body() != null) {
                    User user = response.body();
                    etPhone.setText(user.getPhone());
                    etLastName.setText(user.getLastName());
                    etFirstName.setText(user.getFirstName());
                    etAddress.setText(user.getAddress() != null ? user.getAddress() : "");
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(AccountActivity.this, "Lỗi tải thông tin", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateUserProfile() {
        String lastName = etLastName.getText().toString().trim();
        String firstName = etFirstName.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (lastName.isEmpty() || firstName.isEmpty()) {
            Toast.makeText(this, "Họ tên không được để trống", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User();
        user.setLastName(lastName);
        user.setFirstName(firstName);
        user.setAddress(address);

        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        apiService.updateUserProfile(userId, user).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AccountActivity.this, "Cập nhật thành công!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AccountActivity.this, "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(AccountActivity.this, "Lỗi kết nối", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.menu_account);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            } else if (id == R.id.menu_category) {
                startActivity(new Intent(this, CategoryActivity.class));
                return true;
            } else if (id == R.id.menu_orders) {
                startActivity(new Intent(this, OrderHistoryActivity.class));
                return true;
            }
            return false;
        });
    }
}