package com.example.duannhom;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

import java.util.Random;

public class ForgotPasswordActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        EditText etPhoneForgot = findViewById(R.id.etPhoneForgot);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        
        MaterialButton btnContinue = findViewById(R.id.btnContinue);
        btnContinue.setOnClickListener(v -> {
            String phone = etPhoneForgot.getText().toString();
            if (phone.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập số điện thoại", Toast.LENGTH_SHORT).show();
                return;
            }

            // Tạo mã OTP ngẫu nhiên 6 chữ số
            String randomOtp = String.format("%06d", new Random().nextInt(999999));
            
            // Hiển thị mã OTP bằng Toast để demo
            Toast.makeText(this, "Mã OTP (Demo): " + randomOtp, Toast.LENGTH_LONG).show();

            // Chuyển sang màn hình OTP và gửi kèm mã
            Intent intent = new Intent(this, OtpActivity.class);
            intent.putExtra("EXPECTED_OTP", randomOtp);
            startActivity(intent);
        });
    }
}