package com.example.duannhom;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartActivity extends AppCompatActivity {

    private TextView tvTotalPrice, tvEmptyCart;
    private final List<CartItem> cartItems = new ArrayList<>();
    private CartAdapter adapter;
    private RecyclerView rvCartItems;
    private ApiService apiService;
    private String cartId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        apiService = RetrofitClient.getClient().create(ApiService.class);
        SharedPreferences prefs = getSharedPreferences("CartPrefs", MODE_PRIVATE);
        cartId = prefs.getString("cart_id", null);

        ImageView ivBack = findViewById(R.id.btnBack);
        tvTotalPrice = findViewById(R.id.tvCartTotalPrice);
        tvEmptyCart = findViewById(R.id.tvEmptyCart);
        rvCartItems = findViewById(R.id.rvCart);
        TextView tvClearAll = findViewById(R.id.tvClearAll);
        MaterialButton btnCheckout = findViewById(R.id.btnCheckout);

        ivBack.setOnClickListener(v -> finish());

        adapter = new CartAdapter(this, cartItems, totalPrice -> {
            updateTotalPriceUI();
            // Khi có sự thay đổi từ Adapter (tăng/giảm/xóa), cập nhật lại Manager để đồng bộ badge ở các màn hình khác
            CartManager.getInstance().setCartItems(cartItems);
        });

        rvCartItems.setLayoutManager(new LinearLayoutManager(this));
        rvCartItems.setAdapter(adapter);
        
        if (cartId != null) {
            fetchCartFromServer();
        } else {
            updateUI();
        }

        tvClearAll.setOnClickListener(v -> {
            if (cartId != null) {
                apiService.clearCart(cartId).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.isSuccessful()) {
                            cartItems.clear();
                            CartManager.getInstance().setCartItems(cartItems);
                            adapter.notifyDataSetChanged();
                            updateUI();
                        }
                    }
                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {}
                });
            }
        });

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Giỏ hàng đang trống", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(CartActivity.this, CheckoutActivity.class);
                startActivity(intent);
            }
        });
    }

    private void fetchCartFromServer() {
        apiService.getCartDetails(cartId).enqueue(new Callback<List<CartItem>>() {
            @Override
            public void onResponse(Call<List<CartItem>> call, Response<List<CartItem>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    cartItems.clear();
                    cartItems.addAll(response.body());
                    adapter.notifyDataSetChanged();
                    
                    // ĐỒNG BỘ: Cập nhật dữ liệu vào CartManager để các màn hình khác (Home, Category) thấy badge đúng
                    CartManager.getInstance().setCartItems(response.body());
                    
                    updateUI();
                } else if (response.code() == 404) {
                    // Nếu giỏ hàng không tồn tại trên server, xóa local và cập nhật UI
                    cartItems.clear();
                    CartManager.getInstance().setCartItems(cartItems);
                    updateUI();
                }
            }
            @Override
            public void onFailure(Call<List<CartItem>> call, Throwable t) {
                updateUI();
            }
        });
    }

    private void updateUI() {
        updateTotalPriceUI();
        tvEmptyCart.setVisibility(cartItems.isEmpty() ? View.VISIBLE : View.GONE);
        rvCartItems.setVisibility(cartItems.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void updateTotalPriceUI() {
        long total = 0;
        for (CartItem item : cartItems) {
            total += item.price * item.quantity;
        }
        DecimalFormat formatter = new DecimalFormat("#,###");
        tvTotalPrice.setText(formatter.format(total).replace(",", ".") + "đ");
    }
}