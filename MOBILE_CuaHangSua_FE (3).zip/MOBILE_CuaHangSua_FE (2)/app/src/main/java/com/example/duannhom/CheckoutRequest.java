package com.example.duannhom;

import com.google.gson.annotations.SerializedName;

public class CheckoutRequest {
    @SerializedName("user_id")
    private final int userId;

    @SerializedName("cart_id")
    private final String cartId;

    @SerializedName("full_name")
    private final String fullName;

    @SerializedName("phone")
    private final String phone;

    @SerializedName("address")
    private final String address;

    @SerializedName("payment_method")
    private final String paymentMethod;

    @SerializedName("total_amount")
    private final long totalAmount;

    public CheckoutRequest(int userId, String cartId, String fullName, String phone, String address, String paymentMethod, long totalAmount) {
        this.userId = userId;
        this.cartId = cartId;
        this.fullName = fullName;
        this.phone = phone;
        this.address = address;
        this.paymentMethod = paymentMethod;
        this.totalAmount = totalAmount;
    }
}
