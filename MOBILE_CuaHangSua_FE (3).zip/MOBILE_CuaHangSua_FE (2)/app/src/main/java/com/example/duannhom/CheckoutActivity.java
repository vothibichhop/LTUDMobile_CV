package com.example.duannhom;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {

    private EditText etFullName, etPhone, etAddress;
    private TextView tvTotalAmount;
    private MaterialButton btnConfirmCheckout;
    private RecyclerView rvCheckoutItems;
    private CheckoutItemAdapter adapter;
    private final List<CartItem> checkoutList = new ArrayList<>();
    private long totalAmount = 0;
    private String cartId;
    private int userId;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        apiService = RetrofitClient.getClient().create(ApiService.class);
        
        SharedPreferences cartPrefs = getSharedPreferences("CartPrefs", MODE_PRIVATE);
        cartId = cartPrefs.getString("cart_id", null);
        
        SharedPreferences userPrefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        userId = userPrefs.getInt("user_id", -1);

        initViews();
        setupRecyclerView();
        
        if (userId != -1) {
            fetchUserProfile();
        } else {
            Toast.makeText(this, "Vui lòng đăng nhập để tiếp tục", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        if (cartId != null) {
            fetchCartDetails();
        } else {
            Toast.makeText(this, "Không tìm thấy giỏ hàng", Toast.LENGTH_SHORT).show();
            finish();
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        btnConfirmCheckout.setOnClickListener(v -> processCheckout());
    }

    private void initViews() {
        etFullName = findViewById(R.id.etFullName);
        etPhone = findViewById(R.id.etPhone);
        etAddress = findViewById(R.id.etAddress);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        btnConfirmCheckout = findViewById(R.id.btnConfirmCheckout);
        rvCheckoutItems = findViewById(R.id.rvCheckoutItems);
    }

    private void setupRecyclerView() {
        adapter = new CheckoutItemAdapter(checkoutList);
        rvCheckoutItems.setLayoutManager(new LinearLayoutManager(this));
        rvCheckoutItems.setAdapter(adapter);
    }

    private void fetchUserProfile() {
        apiService.getUserProfile(userId).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful() && response.body() != null) {
                    User user = response.body();
                    if (user.getFullName() != null) etFullName.setText(user.getFullName());
                    else if (user.getFirstName() != null) etFullName.setText(user.getFirstName());
                    
                    if (user.getPhone() != null) etPhone.setText(user.getPhone());
                    if (user.getAddress() != null) etAddress.setText(user.getAddress());
                } else if (response.code() == 404) {
                    handleUserNotFound();
                }
            }
            @Override
            public void onFailure(Call<User> call, Throwable t) {}
        });
    }

    private void handleUserNotFound() {
        Toast.makeText(this, "Tài khoản không tồn tại hoặc đã bị xóa. Vui lòng đăng nhập lại.", Toast.LENGTH_LONG).show();
        getSharedPreferences("UserPrefs", MODE_PRIVATE).edit().clear().apply();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void fetchCartDetails() {
        apiService.getCartDetails(cartId).enqueue(new Callback<List<CartItem>>() {
            @Override
            public void onResponse(Call<List<CartItem>> call, Response<List<CartItem>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    checkoutList.clear();
                    checkoutList.addAll(response.body());
                    adapter.notifyDataSetChanged();
                    calculateTotal();
                }
            }
            @Override
            public void onFailure(Call<List<CartItem>> call, Throwable t) {
                Toast.makeText(CheckoutActivity.this, "Không thể tải chi tiết giỏ hàng", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void calculateTotal() {
        totalAmount = 0;
        for (CartItem item : checkoutList) {
            totalAmount += item.price * item.quantity;
        }
        updateTotalUI();
    }

    private void updateTotalUI() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
        symbols.setGroupingSeparator('.');
        DecimalFormat formatter = new DecimalFormat("#,###", symbols);
        tvTotalAmount.setText(formatter.format(totalAmount) + "đ");
    }

    private void processCheckout() {
        String name = etFullName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        if (userId == -1) {
            Toast.makeText(this, "Vui lòng đăng nhập để thanh toán", Toast.LENGTH_SHORT).show();
            return;
        }

        CheckoutRequest request = new CheckoutRequest(userId, cartId, name, phone, address, "COD", totalAmount);

        btnConfirmCheckout.setEnabled(false);
        btnConfirmCheckout.setText("Đang xử lý...");

        apiService.checkout(request).enqueue(new Callback<OrderResponse>() {
            @Override
            public void onResponse(Call<OrderResponse> call, Response<OrderResponse> response) {
                if (response.isSuccessful()) {
                    completeCheckout(name, phone, address);
                } else {
                    btnConfirmCheckout.setEnabled(true);
                    btnConfirmCheckout.setText("Thanh toán ngay");
                    if (response.code() == 404) {
                        handleUserNotFound();
                    } else {
                        Toast.makeText(CheckoutActivity.this, "Lỗi thanh toán: " + response.code(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<OrderResponse> call, Throwable t) {
                btnConfirmCheckout.setEnabled(true);
                btnConfirmCheckout.setText("Thanh toán ngay");
                Toast.makeText(CheckoutActivity.this, "Lỗi kết nối Server", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void completeCheckout(String name, String phone, String address) {
        getSharedPreferences("CartPrefs", MODE_PRIVATE).edit().remove("cart_id").apply();
        CartManager.getInstance().setCartItems(new ArrayList<>());

        Intent intent = new Intent(CheckoutActivity.this, CheckoutSuccessActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("phone", phone);
        intent.putExtra("address", address);
        intent.putExtra("total", totalAmount);
        startActivity(intent);
        finish();
    }
}
