package com.example.duannhom;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private final List<CartItem> cartItems = new ArrayList<>();
    
    public interface OnCartChangeListener {
        void onCartUpdated(int newCount);
    }
    private final List<OnCartChangeListener> listeners = new ArrayList<>();

    private CartManager() {}

    public static synchronized CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    public void addListener(OnCartChangeListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
        listener.onCartUpdated(getCartCount());
    }

    public void removeListener(OnCartChangeListener listener) {
        listeners.remove(listener);
    }

    public void notifyListeners() {
        int count = getCartCount();
        for (OnCartChangeListener listener : listeners) {
            if (listener != null) listener.onCartUpdated(count);
        }
    }

    public void setCartItems(List<CartItem> items) {
        cartItems.clear();
        if (items != null) {
            cartItems.addAll(items);
        }
        notifyListeners();
    }

    public void addToCartLocal(CartItem item) {
        boolean found = false;
        for (CartItem i : cartItems) {
            if (i.productId != null && i.productId.equals(item.productId)) {
                i.quantity += item.quantity;
                found = true;
                break;
            }
        }
        if (!found) cartItems.add(item);
        notifyListeners();
    }

    public int getCartCount() {
        int total = 0;
        for (CartItem item : cartItems) {
            total += item.quantity;
        }
        return total;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }
}
