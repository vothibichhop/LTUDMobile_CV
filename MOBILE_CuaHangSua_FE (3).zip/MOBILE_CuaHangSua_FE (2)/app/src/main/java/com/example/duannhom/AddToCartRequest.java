package com.example.duannhom;

import com.google.gson.annotations.SerializedName;

public class AddToCartRequest {
    @SerializedName("ma_sua")
    private final String productId;

    @SerializedName("so_luong")
    private final int quantity;

    public AddToCartRequest(String productId, int quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }
}
