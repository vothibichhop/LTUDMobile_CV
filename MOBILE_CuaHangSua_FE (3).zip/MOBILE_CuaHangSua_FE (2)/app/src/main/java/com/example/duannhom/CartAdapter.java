package com.example.duannhom;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.text.DecimalFormat;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    private final List<CartItem> list;
    private final OnCartChangeListener listener;
    private final Context context;
    private final String cartId;
    private final DecimalFormat formatter = new DecimalFormat("#,###");

    public interface OnCartChangeListener { void onTotalChanged(long total); }

    public CartAdapter(Context c, List<CartItem> list, OnCartChangeListener l) {
        this.context = c;
        this.list = list;
        this.listener = l;
        this.cartId = c.getSharedPreferences("CartPrefs", Context.MODE_PRIVATE).getString("cart_id", null);
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_cart, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int p) {
        CartItem item = list.get(p);
        String url = item.imageUrl;
        if (url != null && !url.startsWith("http")) url = RetrofitClient.BASE_URL.replaceAll("/$", "") + url;

        Glide.with(context).load(url).placeholder(R.drawable.thtruemilk).into(h.ivProduct);
        h.tvName.setText(item.name);
        h.tvInfo.setText(item.info);
        h.tvPrice.setText(formatter.format(item.price).replace(",", ".") + "đ");
        h.tvQuantity.setText(String.valueOf(item.quantity));

        h.btnPlus.setOnClickListener(v -> updateQty(h.getAdapterPosition(), 1));
        h.btnMinus.setOnClickListener(v -> {
            int pos = h.getAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {
                if (list.get(pos).quantity > 1) updateQty(pos, -1); else showDel(pos);
            }
        });
    }

    private void updateQty(int pos, int delta) {
        if (pos == RecyclerView.NO_POSITION || cartId == null) return;
        CartItem item = list.get(pos);
        
        // Sử dụng helper để lấy ID (id hoặc productId nếu id null)
        String apiItemId = item.getItemIdForApi();
        if (apiItemId == null) {
            Toast.makeText(context, "Lỗi: Không xác định được ID sản phẩm", Toast.LENGTH_SHORT).show();
            return;
        }

        int oldQty = item.quantity;
        item.quantity += delta;
        notifyItemChanged(pos);
        updateTotal();
        
        RetrofitClient.getClient().create(ApiService.class)
            .updateCartItemQuantity(cartId, apiItemId, new AddToCartRequest(item.productId, item.quantity))
            .enqueue(new Callback<Void>() {
                @Override public void onResponse(Call<Void> c, Response<Void> r) {
                    if (!r.isSuccessful()) rollback(item, oldQty);
                }
                @Override public void onFailure(Call<Void> c, Throwable t) { rollback(item, oldQty); }
            });
    }

    private void rollback(CartItem item, int oldQty) {
        int pos = list.indexOf(item);
        if (pos != -1) {
            item.quantity = oldQty;
            notifyItemChanged(pos);
            updateTotal();
            Toast.makeText(context, "Lỗi cập nhật số lượng", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDel(int pos) {
        if (pos == RecyclerView.NO_POSITION || cartId == null) return;
        CartItem itemToRemove = list.get(pos);
        
        String apiItemId = itemToRemove.getItemIdForApi();
        if (apiItemId == null) {
            Toast.makeText(context, "Lỗi: Không xác định được ID để xóa", Toast.LENGTH_SHORT).show();
            return;
        }

        View v = LayoutInflater.from(context).inflate(R.layout.dialog_remove_item, null);
        AlertDialog d = new AlertDialog.Builder(context, R.style.CustomDialogTheme).setView(v).create();
        v.findViewById(R.id.btnCancel).setOnClickListener(view -> d.dismiss());
        v.findViewById(R.id.btnConfirm).setOnClickListener(view -> {
            RetrofitClient.getClient().create(ApiService.class).deleteCartItem(cartId, apiItemId)
                .enqueue(new Callback<Void>() {
                    @Override public void onResponse(Call<Void> c, Response<Void> r) {
                        if (r.isSuccessful()) {
                            int currentPos = list.indexOf(itemToRemove);
                            if (currentPos != -1) {
                                list.remove(currentPos);
                                notifyItemRemoved(currentPos);
                                updateTotal();
                            }
                        } else {
                            Toast.makeText(context, "Không thể xóa sản phẩm", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override public void onFailure(Call<Void> c, Throwable t) {
                        Toast.makeText(context, "Lỗi kết nối", Toast.LENGTH_SHORT).show();
                    }
                });
            d.dismiss();
        });
        d.show();
    }

    private void updateTotal() {
        long t = 0; for (CartItem i : list) t += i.price * i.quantity;
        if (listener != null) listener.onTotalChanged(t);
        CartManager.getInstance().setCartItems(list);
    }

    @Override public int getItemCount() { return list.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProduct;
        TextView tvName, tvInfo, tvPrice, tvQuantity, btnPlus, btnMinus;
        public ViewHolder(View v) {
            super(v);
            ivProduct = v.findViewById(R.id.ivCartProduct);
            tvName = v.findViewById(R.id.tvCartProductName);
            tvInfo = v.findViewById(R.id.tvCartProductSpec);
            tvPrice = v.findViewById(R.id.tvCartProductPrice);
            tvQuantity = v.findViewById(R.id.tvCartQuantity);
            btnPlus = v.findViewById(R.id.btnCartPlus);
            btnMinus = v.findViewById(R.id.btnCartMinus);
        }
    }
}
