package com.example.duannhom;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import java.text.DecimalFormat;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    private int quantity = 1;
    private long currentPriceValue = 0;
    private long basePriceValue = 0;
    private final long secondaryPriceValue = 41400;
    private TextView tvQuantity, tvProductName, tvProductPrice, tvProductDesc, tvSpecification, tvToolbarTitle;
    private ImageView ivProduct;
    private Button btnAddToCart;
    private Product currentProduct;
    private ApiService apiService;
    private LinearLayout option1, option2;
    private RadioButton rb1, rb2;
    private static final String PREFS_NAME = "CartPrefs";
    private static final String KEY_CART_ID = "cart_id";
    
    private static final Pattern UUID_PATTERN = 
        Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        apiService = RetrofitClient.getClient().create(ApiService.class);

        // Ánh xạ View
        ImageView btnBack = findViewById(R.id.btnBack);
        TextView btnPlus = findViewById(R.id.btnPlus);
        TextView btnMinus = findViewById(R.id.btnMinus);
        tvQuantity = findViewById(R.id.tvQuantity);
        btnAddToCart = findViewById(R.id.btnAddToCart);
        tvToolbarTitle = findViewById(R.id.tvToolbarTitle);
        ivProduct = findViewById(R.id.ivProductDetail);
        tvProductName = findViewById(R.id.tvProductNameDetail);
        tvProductPrice = findViewById(R.id.tvProductPriceDetail);
        tvProductDesc = findViewById(R.id.tvDescriptionDetail);
        tvSpecification = findViewById(R.id.tvSpecificationDetail);

        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        rb1 = (RadioButton) option1.getChildAt(0);
        rb2 = (RadioButton) option2.getChildAt(0);

        String productId = getIntent().getStringExtra("PRODUCT_ID");
        if (productId != null) {
            fetchProductDetail(productId);
        }

        btnBack.setOnClickListener(v -> finish());
        btnPlus.setOnClickListener(v -> { quantity++; updateCartButton(); });
        btnMinus.setOnClickListener(v -> { if (quantity > 1) { quantity--; updateCartButton(); } });

        option1.setOnClickListener(v -> selectOption(1));
        option2.setOnClickListener(v -> selectOption(2));

        btnAddToCart.setOnClickListener(v -> {
            if (currentProduct != null) {
                checkAndAddToCart();
            } else {
                Toast.makeText(this, "Đang tải dữ liệu...", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void selectOption(int opt) {
        if (opt == 1) {
            rb1.setChecked(true);
            rb2.setChecked(false);
            option1.setAlpha(1.0f);
            option2.setAlpha(0.6f);
            currentPriceValue = basePriceValue;
        } else {
            rb1.setChecked(false);
            rb2.setChecked(true);
            option1.setAlpha(0.6f);
            option2.setAlpha(1.0f);
            currentPriceValue = secondaryPriceValue;
        }
        updateCartButton();
    }

    private void checkAndAddToCart() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String cartId = prefs.getString(KEY_CART_ID, null);

        if (cartId == null || !UUID_PATTERN.matcher(cartId).matches()) {
            createNewCart();
        } else {
            addToCartOnServer(cartId);
        }
    }

    private void createNewCart() {
        apiService.createCart().enqueue(new Callback<CartResponse>() {
            @Override
            public void onResponse(Call<CartResponse> call, Response<CartResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String newCartId = response.body().getCartId();
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(KEY_CART_ID, newCartId).apply();
                    addToCartOnServer(newCartId);
                } else {
                    Toast.makeText(ProductDetailActivity.this, "Không thể tạo giỏ hàng", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<CartResponse> call, Throwable t) {
                Toast.makeText(ProductDetailActivity.this, "Lỗi kết nối khi tạo giỏ", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addToCartOnServer(String cartId) {
        AddToCartRequest request = new AddToCartRequest(currentProduct.id, quantity);
        Log.d("API_DEBUG", "Adding to cart " + cartId + ": " + new Gson().toJson(request));

        apiService.addProductToCart(cartId, request).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(ProductDetailActivity.this, "Đã thêm vào giỏ hàng!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ProductDetailActivity.this, MainActivity.class);
                    intent.putExtra("show_success", true);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                    finish();
                } else if (response.code() == 404) {
                    // Nếu Server báo 404 (Giỏ hàng không tồn tại), xóa ID cũ và tạo giỏ hàng mới
                    Log.e("API_DEBUG", "Cart ID expired or not found. Creating new one...");
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().remove(KEY_CART_ID).apply();
                    createNewCart();
                } else {
                    Toast.makeText(ProductDetailActivity.this, "Lỗi thêm giỏ hàng: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(ProductDetailActivity.this, "Lỗi kết nối server", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchProductDetail(String maSP) {
        apiService.getProductDetail(maSP).enqueue(new Callback<Product>() {
            @Override
            public void onResponse(Call<Product> call, Response<Product> response) {
                if (response.isSuccessful() && response.body() != null) {
                    currentProduct = response.body();
                    displayProductData(currentProduct);
                }
            }
            @Override
            public void onFailure(Call<Product> call, Throwable t) {}
        });
    }

    private void displayProductData(Product product) {
        if (tvProductName != null) tvProductName.setText(product.name);
        if (tvToolbarTitle != null) tvToolbarTitle.setText(product.name);
        if (tvProductDesc != null) tvProductDesc.setText(product.description);
        if (tvSpecification != null) tvSpecification.setText(product.specification);
        
        // Gán giá hiển thị (Khắc phục lỗi 0đ)
        if (tvProductPrice != null) tvProductPrice.setText(product.price + "đ");
        
        try {
            String cleanPrice = product.price.replaceAll("[^0-9]", "");
            basePriceValue = Long.parseLong(cleanPrice);
            currentPriceValue = basePriceValue;
        } catch (Exception e) {
            basePriceValue = 0;
            currentPriceValue = 0;
        }

        if (ivProduct != null) {
            Glide.with(this).load(product.imageUrl).placeholder(R.drawable.thtruemilk).into(ivProduct);
        }
        updateCartButton();
    }

    private void updateCartButton() {
        if (tvQuantity != null) tvQuantity.setText(String.valueOf(quantity));
        long totalPrice = quantity * currentPriceValue;
        DecimalFormat formatter = new DecimalFormat("#,###");
        String formattedPrice = formatter.format(totalPrice).replace(",", ".") + "đ";
        if (btnAddToCart != null) {
            btnAddToCart.setText(formattedPrice + " | Thêm vào giỏ");
        }
    }
}