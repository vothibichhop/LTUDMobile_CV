package com.example.duannhom

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class OrderHistoryActivity : AppCompatActivity() {

    private lateinit var rvOrders: RecyclerView
    private lateinit var tvEmptyOrders: TextView
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_history)

        rvOrders = findViewById(R.id.rvOrders)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        tvEmptyOrders = findViewById(R.id.tvEmptyOrders)
        
        btnBack?.setOnClickListener { finish() }

        rvOrders.layoutManager = LinearLayoutManager(this)
        
        val prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        userId = prefs.getInt("user_id", -1)
        
        setupBottomNav()

        if (userId != -1) {
            fetchOrderHistory()
        } else {
            tvEmptyOrders.visibility = View.VISIBLE
            tvEmptyOrders.text = "Vui lòng đăng nhập để xem đơn hàng"
        }
    }

    private fun setupBottomNav() {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav?.let {
            it.selectedItemId = R.id.menu_orders
            it.setOnItemSelectedListener { item ->
                when (item.itemId) {
                    R.id.menu_home -> { startActivity(Intent(this, MainActivity::class.java)); true }
                    R.id.menu_category -> { startActivity(Intent(this, CategoryActivity::class.java)); true }
                    R.id.menu_account -> { startActivity(Intent(this, AccountActivity::class.java)); true }
                    else -> false
                }
            }
        }
    }

    private fun fetchOrderHistory() {
        val apiService = RetrofitClient.getClient().create(ApiService::class.java)
        
        // Log URL để bạn kiểm tra trong Logcat (Tag: API_URL)
        Log.d("API_URL", "Đang gọi: ${RetrofitClient.BASE_URL}api/lich-su-don-hang?user_id=$userId")

        apiService.getOrderHistory(userId).enqueue(object : Callback<List<OrderResponse>> {
            override fun onResponse(call: Call<List<OrderResponse>>, response: Response<List<OrderResponse>>) {
                if (response.isSuccessful) {
                    val orders = response.body()
                    if (orders.isNullOrEmpty()) {
                        tvEmptyOrders.visibility = View.VISIBLE
                        rvOrders.visibility = View.GONE
                        tvEmptyOrders.text = "Bạn chưa có đơn hàng nào"
                    } else {
                        tvEmptyOrders.visibility = View.GONE
                        rvOrders.visibility = View.VISIBLE
                        rvOrders.adapter = OrderAdapter(orders, { showOrderDetail(it) }, { confirmCancelOrder(it) })
                    }
                } else {
                    tvEmptyOrders.visibility = View.VISIBLE
                    // Nếu vẫn 404, nghĩa là Route Laravel của bạn đang khác hoàn toàn.
                    tvEmptyOrders.text = "Lỗi ${response.code()}: Server không tìm thấy Route /api/lich-su-don-hang"
                }
            }

            override fun onFailure(call: Call<List<OrderResponse>>, t: Throwable) {
                tvEmptyOrders.visibility = View.VISIBLE
                tvEmptyOrders.text = "Lỗi kết nối máy chủ"
            }
        })
    }

    private fun confirmCancelOrder(order: OrderResponse) {
        AlertDialog.Builder(this)
            .setTitle("Hủy đơn hàng")
            .setMessage("Bạn có chắc chắn muốn hủy đơn hàng #${order.id}?")
            .setPositiveButton("Hủy đơn") { _, _ -> cancelOrder(order.id ?: "") }
            .setNegativeButton("Quay lại", null)
            .show()
    }

    private fun cancelOrder(orderId: String) {
        val apiService = RetrofitClient.getClient().create(ApiService::class.java)
        apiService.cancelOrder(orderId).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@OrderHistoryActivity, "Đã hủy đơn hàng", Toast.LENGTH_SHORT).show()
                    fetchOrderHistory()
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {}
        })
    }

    private fun showOrderDetail(order: OrderResponse) {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.dialog_order_detail, null)
        view.findViewById<TextView>(R.id.tvDetailOrderId).text = "Mã ĐH: ${order.id ?: "N/A"}"
        view.findViewById<TextView>(R.id.tvDetailStatus).text = order.trangThai ?: "N/A"
        view.findViewById<TextView>(R.id.tvDetailTotal).text = String.format("%,.0fđ", order.tongTien ?: 0.0)
        
        val productListContainer = view.findViewById<LinearLayout>(R.id.llDetailProductList)
        productListContainer.removeAllViews()
        
        order.sanPham?.forEach { product ->
            val pView = layoutInflater.inflate(R.layout.item_order_detail_product, null)
            pView.findViewById<TextView>(R.id.tvDetailProductName).text = product.tenSp ?: "Sản phẩm"
            pView.findViewById<TextView>(R.id.tvDetailProductQtyPrice).text =
                "SL: ${product.soLuong ?: 0} × ${String.format("%,.0fđ", product.giaBan ?: 0.0)}"

            val ivProductImage = pView.findViewById<ImageView>(R.id.ivDetailProductImage)
            var url = product.hinhAnh
            if (url != null && !url.startsWith("http")) {
                url = RetrofitClient.BASE_URL + url.trimStart('/')
            }
            Glide.with(this).load(url).placeholder(R.drawable.thtruemilk).into(ivProductImage)
            productListContainer.addView(pView)
        }
        
        dialog.setContentView(view)
        dialog.show()
    }

    class OrderAdapter(
        private val orders: List<OrderResponse>,
        private val onDetailClick: (OrderResponse) -> Unit,
        private val onCancelClick: (OrderResponse) -> Unit
    ) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

        class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvOrderId: TextView? = view.findViewById(R.id.tvOrderId)
            val tvDateTime: TextView = view.findViewById(R.id.tvOrderDateTime)
            val tvStatus: TextView = view.findViewById(R.id.tvOrderStatus)
            val tvTotal: TextView = view.findViewById(R.id.tvTotalPrice)
            val llProductContainer: LinearLayout = view.findViewById(R.id.llProductContainer)
            val btnAction: View = view.findViewById(R.id.btnAction)
            val btnCancel: Button = view.findViewById(R.id.btnCancel)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_order_card, parent, false)
            return OrderViewHolder(view)
        }

        override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
            val order = orders[position]
            val context = holder.itemView.context
            
            holder.tvOrderId?.text = "Đơn hàng #${order.id ?: ""}"
            holder.tvDateTime.text = order.ngayDat ?: ""
            holder.tvStatus.text = order.trangThai ?: ""
            holder.tvTotal.text = String.format("%,.0fđ", order.tongTien ?: 0.0)

            val statusColor = when (order.trangThai) {
                "Đang giao" -> android.R.color.holo_blue_dark
                "Hoàn thành" -> android.R.color.holo_green_dark
                "Đã hủy" -> android.R.color.holo_red_dark
                else -> android.R.color.holo_orange_dark
            }
            holder.tvStatus.setTextColor(ContextCompat.getColor(context, statusColor))

            holder.btnCancel.visibility = if (order.trangThai == "Chờ xác nhận") View.VISIBLE else View.GONE
            
            holder.llProductContainer.removeAllViews()
            order.sanPham?.take(2)?.forEach { product ->
                val pView = LayoutInflater.from(context).inflate(R.layout.item_order_product, holder.llProductContainer, false)
                pView.findViewById<TextView>(R.id.tvProductName).text = product.tenSp ?: "Sản phẩm"
                pView.findViewById<TextView>(R.id.tvProductQuantity).text = "x${product.soLuong ?: 0}"
                holder.llProductContainer.addView(pView)
            }

            holder.btnAction.setOnClickListener { onDetailClick(order) }
            holder.btnCancel.setOnClickListener { onCancelClick(order) }
        }

        override fun getItemCount() = orders.size
    }
}
