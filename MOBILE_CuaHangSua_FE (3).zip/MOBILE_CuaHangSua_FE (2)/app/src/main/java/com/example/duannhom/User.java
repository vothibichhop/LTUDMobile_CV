package com.example.duannhom;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("id")
    private int id;

    @SerializedName("so_dien_thoai")
    private String phone;

    @SerializedName("ho_ten_dem")
    private String lastName;

    @SerializedName("ten")
    private String firstName;
    
    @SerializedName("ho_ten") // Trường mới bạn vừa thêm ở Django
    private String fullName;

    @SerializedName("dia_chi")
    private String address;

    // Getters
    public int getId() { return id; }
    public String getPhone() { return phone; }
    public String getLastName() { return lastName; }
    public String getFirstName() { return firstName; }
    public String getFullName() { return fullName; }
    public String getAddress() { return address; }

    // Setters
    public void setLastName(String lastName) { this.lastName = lastName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public void setAddress(String address) { this.address = address; }
}