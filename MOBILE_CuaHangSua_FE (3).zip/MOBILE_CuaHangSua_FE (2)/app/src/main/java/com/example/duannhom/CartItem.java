package com.example.duannhom;

import com.google.gson.annotations.SerializedName;

public class CartItem {
    // ID dùng để định danh khi UPDATE/DELETE (thường là ID chi tiết giỏ hàng trên Server)
    @SerializedName(value = "id", alternate = {"chi_tiet_id", "ma_chi_tiet", "ma_ctgh", "ma_ct_gio_hang", "ma_chi_tiet_gio_hang"})
    public String id;

    // Mã sản phẩm (ma_sua)
    @SerializedName(value = "ma_sua", alternate = {"productId", "ma_sp", "id_sua", "id_sp", "product_id"})
    public String productId;

    @SerializedName(value = "hinh_anh", alternate = {"hinh", "image", "hinh_sua"})
    public String imageUrl;

    @SerializedName(value = "ten_sp", alternate = {"ten_sua", "name", "ten_san_pham"})
    public String name;

    @SerializedName(value = "quy_cach", alternate = {"info", "specification", "don_vi_tinh"})
    public String info;

    @SerializedName(value = "gia", alternate = {"don_gia", "price", "gia_ban"})
    public long price;

    @SerializedName(value = "so_luong", alternate = {"quantity", "qty", "sl"})
    public int quantity;

    public CartItem() {}

    public CartItem(String productId, String imageUrl, String name, String info, long price, int quantity) {
        this.productId = productId;
        this.imageUrl = imageUrl;
        this.name = name;
        this.info = info;
        this.price = price;
        this.quantity = quantity;
        this.id = productId; // Mặc định dùng productId làm ID nếu không được gán từ JSON
    }

    /**
     * Lấy ID an toàn để gọi API Update/Delete.
     * Ưu tiên id (chi tiết), nếu null sẽ dùng productId.
     */
    public String getItemIdForApi() {
        if (id != null && !id.trim().isEmpty()) return id;
        if (productId != null && !productId.trim().isEmpty()) return productId;
        return null;
    }
}
