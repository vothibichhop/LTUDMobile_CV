package com.example.duannhom

import com.google.gson.annotations.SerializedName

data class OrderResponse(
    @SerializedName("id") val id: String?,
    @SerializedName("ngay_dat") val ngayDat: String?,
    @SerializedName("trang_thai") val trangThai: String?,
    @SerializedName("tong_tien") val tongTien: Double?,
    @SerializedName("san_pham") val sanPham: List<OrderProduct>?,
    @SerializedName("full_name") val fullName: String? = null,
    @SerializedName("phone") val phone: String? = null,
    @SerializedName("address") val address: String? = null,
    @SerializedName("payment_method") val paymentMethod: String? = null
)

data class OrderProduct(
    @SerializedName("ten_sp") val tenSp: String?,
    @SerializedName("so_luong") val soLuong: Int?,
    @SerializedName("gia_ban") val giaBan: Double?,
    @SerializedName("hinh_anh") val hinhAnh: String?
)
