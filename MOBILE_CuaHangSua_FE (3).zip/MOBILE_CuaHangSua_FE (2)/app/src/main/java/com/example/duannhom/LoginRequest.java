package com.example.duannhom;

import com.google.gson.annotations.SerializedName;

public class LoginRequest {
    @SerializedName("so_dien_thoai")
    private final String phone;
    @SerializedName("mat_khau")
    private final String password;

    public LoginRequest(String phone, String password) {
        this.phone = phone;
        this.password = password;
    }
}